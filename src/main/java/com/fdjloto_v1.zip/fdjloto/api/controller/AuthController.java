// package com.fdjloto.api.controller;

// import com.fdjloto.api.model.User;
// import com.fdjloto.api.security.JwtUtil;
// import com.fdjloto.api.service.UserService;
// import io.swagger.v3.oas.annotations.Operation;
// import io.swagger.v3.oas.annotations.tags.Tag;
// import org.springframework.http.ResponseEntity;
// import org.springframework.security.authentication.AuthenticationManager;
// import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
// import org.springframework.security.core.userdetails.UserDetails;
// import org.springframework.web.bind.annotation.*;

// import java.util.HashMap;
// import java.util.Map;

// @RestController
// @RequestMapping("/api/auth")
// @Tag(name = "Auth API", description = "Gestion de l'authentification et des tokens")
// public class AuthController {

//     private final AuthenticationManager authenticationManager;
//     private final UserService userService;
//     private final JwtUtil jwtUtil;

//     public AuthController(AuthenticationManager authenticationManager, UserService userService, JwtUtil jwtUtil) {
//         this.authenticationManager = authenticationManager;
//         this.userService = userService;
//         this.jwtUtil = jwtUtil;
//     }

//     @PostMapping("/login")
//     @Operation(summary = "Authentification par email et mot de passe")
//     public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
//         String email = request.get("email");
//         String password = request.get("password");

//         authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(email, password));

//         final UserDetails userDetails = userService.loadUserByUsername(email);
//         final String jwt = jwtUtil.generateToken(userDetails);

//         Map<String, String> response = new HashMap<>();
//         response.put("token", jwt);
//         return ResponseEntity.ok(response);
//     }

//     @PostMapping("/token")
//     @Operation(summary = "Générer un nouveau token JWT")
//     public ResponseEntity<?> generateToken(@RequestBody Map<String, String> request) {
//         String email = request.get("email");

//         final UserDetails userDetails = userService.loadUserByUsername(email);
//         final String jwt = jwtUtil.generateToken(userDetails);

//         Map<String, String> response = new HashMap<>();
//         response.put("token", jwt);
//         return ResponseEntity.ok(response);
//     }
// }
